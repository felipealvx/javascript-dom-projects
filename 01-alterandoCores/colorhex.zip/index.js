const btn = document.getElementById('alter__color')

const colorHexBtn = document.getElementById('colorHexBtn');

function colorHexFunc(){
  let colorHex = document.getElementById('colorHex').value;

  colorHex = [colorHex]

  document.body.style.backgroundColor = '#'+ colorHex;
  console.log(colorHex)
}

colorHexBtn.addEventListener('click', colorHexFunc)


function colorAlter(){
  let r = Math.floor(Math.random() * 255);
  let g = Math.floor(Math.random() * 255);
  let b = Math.floor(Math.random() * 255);
  document.body.style.backgroundColor = ('rgb('+r+','+g+','+b+')');
}

btn.addEventListener('click', colorAlter)